﻿namespace CircodeApps
{
    partial class frmClima
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmClima));
            this.btnPESQUISAR = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtCidade = new System.Windows.Forms.TextBox();
            this.btnFECHAR = new System.Windows.Forms.Button();
            this.lblCidade = new System.Windows.Forms.Label();
            this.lblTemperatura = new System.Windows.Forms.Label();
            this.lblDescricao = new System.Windows.Forms.Label();
            this.lblUmidade = new System.Windows.Forms.Label();
            this.lblPressao = new System.Windows.Forms.Label();
            this.lblPais = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnPESQUISAR
            // 
            this.btnPESQUISAR.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.btnPESQUISAR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPESQUISAR.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPESQUISAR.ForeColor = System.Drawing.Color.White;
            this.btnPESQUISAR.Location = new System.Drawing.Point(335, 41);
            this.btnPESQUISAR.Name = "btnPESQUISAR";
            this.btnPESQUISAR.Size = new System.Drawing.Size(122, 55);
            this.btnPESQUISAR.TabIndex = 0;
            this.btnPESQUISAR.Text = "PESQUISAR";
            this.btnPESQUISAR.UseVisualStyleBackColor = false;
            this.btnPESQUISAR.Click += new System.EventHandler(this.btnPESQUISAR_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(12, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(154, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "DIGITE UMA CIDADE";
            // 
            // txtCidade
            // 
            this.txtCidade.Location = new System.Drawing.Point(12, 59);
            this.txtCidade.Name = "txtCidade";
            this.txtCidade.Size = new System.Drawing.Size(264, 20);
            this.txtCidade.TabIndex = 2;
            // 
            // btnFECHAR
            // 
            this.btnFECHAR.BackColor = System.Drawing.Color.Firebrick;
            this.btnFECHAR.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFECHAR.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFECHAR.ForeColor = System.Drawing.Color.White;
            this.btnFECHAR.Location = new System.Drawing.Point(335, 125);
            this.btnFECHAR.Name = "btnFECHAR";
            this.btnFECHAR.Size = new System.Drawing.Size(122, 55);
            this.btnFECHAR.TabIndex = 3;
            this.btnFECHAR.Text = "FECHAR";
            this.btnFECHAR.UseVisualStyleBackColor = false;
            this.btnFECHAR.Click += new System.EventHandler(this.btnFECHAR_Click);
            // 
            // lblCidade
            // 
            this.lblCidade.AutoSize = true;
            this.lblCidade.BackColor = System.Drawing.Color.Transparent;
            this.lblCidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCidade.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblCidade.Location = new System.Drawing.Point(24, 189);
            this.lblCidade.Name = "lblCidade";
            this.lblCidade.Size = new System.Drawing.Size(0, 15);
            this.lblCidade.TabIndex = 4;
            // 
            // lblTemperatura
            // 
            this.lblTemperatura.AutoSize = true;
            this.lblTemperatura.BackColor = System.Drawing.Color.Transparent;
            this.lblTemperatura.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTemperatura.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblTemperatura.Location = new System.Drawing.Point(24, 226);
            this.lblTemperatura.Name = "lblTemperatura";
            this.lblTemperatura.Size = new System.Drawing.Size(0, 15);
            this.lblTemperatura.TabIndex = 5;
            // 
            // lblDescricao
            // 
            this.lblDescricao.AutoSize = true;
            this.lblDescricao.BackColor = System.Drawing.Color.Transparent;
            this.lblDescricao.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescricao.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblDescricao.Location = new System.Drawing.Point(24, 263);
            this.lblDescricao.Name = "lblDescricao";
            this.lblDescricao.Size = new System.Drawing.Size(0, 15);
            this.lblDescricao.TabIndex = 6;
            // 
            // lblUmidade
            // 
            this.lblUmidade.AutoSize = true;
            this.lblUmidade.BackColor = System.Drawing.Color.Transparent;
            this.lblUmidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUmidade.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblUmidade.Location = new System.Drawing.Point(24, 301);
            this.lblUmidade.Name = "lblUmidade";
            this.lblUmidade.Size = new System.Drawing.Size(0, 15);
            this.lblUmidade.TabIndex = 7;
            // 
            // lblPressao
            // 
            this.lblPressao.AutoSize = true;
            this.lblPressao.BackColor = System.Drawing.Color.Transparent;
            this.lblPressao.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPressao.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblPressao.Location = new System.Drawing.Point(24, 339);
            this.lblPressao.Name = "lblPressao";
            this.lblPressao.Size = new System.Drawing.Size(0, 15);
            this.lblPressao.TabIndex = 8;
            // 
            // lblPais
            // 
            this.lblPais.AutoSize = true;
            this.lblPais.BackColor = System.Drawing.Color.Transparent;
            this.lblPais.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPais.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.lblPais.Location = new System.Drawing.Point(24, 378);
            this.lblPais.Name = "lblPais";
            this.lblPais.Size = new System.Drawing.Size(0, 15);
            this.lblPais.TabIndex = 9;
            // 
            // frmClima
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::CircodeApps.Properties.Resources.paisagem_de_floresta_nublada_23_2151794661;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(500, 450);
            this.Controls.Add(this.lblPais);
            this.Controls.Add(this.lblPressao);
            this.Controls.Add(this.lblUmidade);
            this.Controls.Add(this.lblDescricao);
            this.Controls.Add(this.lblTemperatura);
            this.Controls.Add(this.lblCidade);
            this.Controls.Add(this.btnFECHAR);
            this.Controls.Add(this.txtCidade);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnPESQUISAR);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmClima";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmClima";
            this.Load += new System.EventHandler(this.frmClima_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnPESQUISAR;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtCidade;
        private System.Windows.Forms.Button btnFECHAR;
        private System.Windows.Forms.Label lblCidade;
        private System.Windows.Forms.Label lblTemperatura;
        private System.Windows.Forms.Label lblDescricao;
        private System.Windows.Forms.Label lblUmidade;
        private System.Windows.Forms.Label lblPressao;
        private System.Windows.Forms.Label lblPais;
    }
}
﻿namespace CircodeApps
{
    partial class frmMenu
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMenu));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.pbxFechar = new System.Windows.Forms.PictureBox();
            this.pbxViagem = new System.Windows.Forms.PictureBox();
            this.pbxCaraCoroa = new System.Windows.Forms.PictureBox();
            this.pbxCPF = new System.Windows.Forms.PictureBox();
            this.pbxClima = new System.Windows.Forms.PictureBox();
            this.pbxCEP = new System.Windows.Forms.PictureBox();
            this.pbxCalculadora = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pbxFechar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxViagem)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxCaraCoroa)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxCPF)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxClima)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxCEP)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxCalculadora)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(51, 197);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 16);
            this.label1.TabIndex = 7;
            this.label1.Text = "Calculadora";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(245, 197);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 16);
            this.label2.TabIndex = 8;
            this.label2.Text = "Buscar CEP";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(465, 197);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 16);
            this.label3.TabIndex = 9;
            this.label3.Text = "Clima";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(686, 197);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(36, 16);
            this.label4.TabIndex = 10;
            this.label4.Text = "CPF";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(141, 407);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(107, 16);
            this.label5.TabIndex = 11;
            this.label5.Text = "Cara ou Coroa";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(347, 407);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(95, 16);
            this.label6.TabIndex = 12;
            this.label6.Text = "Calcular rota";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.IndianRed;
            this.label7.Location = new System.Drawing.Point(578, 407);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 16);
            this.label7.TabIndex = 13;
            this.label7.Text = "SAIR";
            // 
            // pbxFechar
            // 
            this.pbxFechar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxFechar.Image = global::CircodeApps.Properties.Resources.sair;
            this.pbxFechar.Location = new System.Drawing.Point(545, 246);
            this.pbxFechar.Name = "pbxFechar";
            this.pbxFechar.Size = new System.Drawing.Size(114, 131);
            this.pbxFechar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxFechar.TabIndex = 6;
            this.pbxFechar.TabStop = false;
            this.pbxFechar.Click += new System.EventHandler(this.pbxFechar_Click_1);
            // 
            // pbxViagem
            // 
            this.pbxViagem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxViagem.Image = global::CircodeApps.Properties.Resources.carro;
            this.pbxViagem.Location = new System.Drawing.Point(324, 228);
            this.pbxViagem.Name = "pbxViagem";
            this.pbxViagem.Size = new System.Drawing.Size(149, 163);
            this.pbxViagem.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxViagem.TabIndex = 5;
            this.pbxViagem.TabStop = false;
            this.pbxViagem.Click += new System.EventHandler(this.pbxViagem_Click);
            // 
            // pbxCaraCoroa
            // 
            this.pbxCaraCoroa.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxCaraCoroa.Image = global::CircodeApps.Properties.Resources.coin;
            this.pbxCaraCoroa.Location = new System.Drawing.Point(120, 228);
            this.pbxCaraCoroa.Name = "pbxCaraCoroa";
            this.pbxCaraCoroa.Size = new System.Drawing.Size(149, 163);
            this.pbxCaraCoroa.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxCaraCoroa.TabIndex = 4;
            this.pbxCaraCoroa.TabStop = false;
            this.pbxCaraCoroa.Click += new System.EventHandler(this.pbxCaraCoroa_Click);
            // 
            // pbxCPF
            // 
            this.pbxCPF.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxCPF.Image = global::CircodeApps.Properties.Resources.iconcpf;
            this.pbxCPF.Location = new System.Drawing.Point(630, 21);
            this.pbxCPF.Name = "pbxCPF";
            this.pbxCPF.Size = new System.Drawing.Size(149, 163);
            this.pbxCPF.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxCPF.TabIndex = 3;
            this.pbxCPF.TabStop = false;
            this.pbxCPF.Click += new System.EventHandler(this.pbxCPF_Click);
            // 
            // pbxClima
            // 
            this.pbxClima.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxClima.Image = global::CircodeApps.Properties.Resources.nublado;
            this.pbxClima.Location = new System.Drawing.Point(418, 21);
            this.pbxClima.Name = "pbxClima";
            this.pbxClima.Size = new System.Drawing.Size(149, 163);
            this.pbxClima.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxClima.TabIndex = 2;
            this.pbxClima.TabStop = false;
            this.pbxClima.Click += new System.EventHandler(this.pbxClima_Click);
            // 
            // pbxCEP
            // 
            this.pbxCEP.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxCEP.Image = global::CircodeApps.Properties.Resources.letter_box;
            this.pbxCEP.Location = new System.Drawing.Point(219, 21);
            this.pbxCEP.Name = "pbxCEP";
            this.pbxCEP.Size = new System.Drawing.Size(149, 163);
            this.pbxCEP.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxCEP.TabIndex = 1;
            this.pbxCEP.TabStop = false;
            this.pbxCEP.Click += new System.EventHandler(this.pbxCEP_Click_1);
            // 
            // pbxCalculadora
            // 
            this.pbxCalculadora.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbxCalculadora.Image = global::CircodeApps.Properties.Resources.calcular;
            this.pbxCalculadora.Location = new System.Drawing.Point(22, 21);
            this.pbxCalculadora.Name = "pbxCalculadora";
            this.pbxCalculadora.Size = new System.Drawing.Size(149, 163);
            this.pbxCalculadora.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxCalculadora.TabIndex = 0;
            this.pbxCalculadora.TabStop = false;
            this.pbxCalculadora.Click += new System.EventHandler(this.pbxCalculadora_Click);
            // 
            // frmMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pbxFechar);
            this.Controls.Add(this.pbxViagem);
            this.Controls.Add(this.pbxCaraCoroa);
            this.Controls.Add(this.pbxCPF);
            this.Controls.Add(this.pbxClima);
            this.Controls.Add(this.pbxCEP);
            this.Controls.Add(this.pbxCalculadora);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Menu";
            ((System.ComponentModel.ISupportInitialize)(this.pbxFechar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxViagem)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxCaraCoroa)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxCPF)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxClima)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxCEP)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxCalculadora)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbxCalculadora;
        private System.Windows.Forms.PictureBox pbxCEP;
        private System.Windows.Forms.PictureBox pbxClima;
        private System.Windows.Forms.PictureBox pbxCPF;
        private System.Windows.Forms.PictureBox pbxCaraCoroa;
        private System.Windows.Forms.PictureBox pbxViagem;
        private System.Windows.Forms.PictureBox pbxFechar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
    }
}


﻿using CircoApps;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CircodeApps
{
    public partial class frmMenu : Form
    {
        public frmMenu()
        {
            InitializeComponent();
            frmSplash splash = new frmSplash();
            splash.Show();
            Application.DoEvents();
            Thread.Sleep(2000);
            splash.Close();
        }

        private void pbxFechar_Click_1(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void pbxCEP_Click_1(object sender, EventArgs e)
        {
            foreach (Form formAberto in Application.OpenForms)
            {
                if (formAberto is frmBuscarCEP)
                {
                    formAberto.Focus();
                    return;
                }
            }
            frmBuscarCEP buscarCEP = new frmBuscarCEP();
            buscarCEP.Show();
        }

        private void pbxCalculadora_Click(object sender, EventArgs e)
        {
            foreach (Form formAberto in Application.OpenForms)
            {
                if (formAberto is frmCalc)
                {
                    formAberto.Focus();
                    return;
                }
            }
            frmCalc Calculadora = new frmCalc();
            Calculadora.Show();
        }

        private void pbxClima_Click(object sender, EventArgs e)
        {
            foreach (Form formAberto in Application.OpenForms)
            {
                if (formAberto is frmClima)
                {
                    formAberto.Focus();
                    return;
                }
            }
            frmClima Clima = new frmClima();
            Clima.Show();
        }

        private void pbxCPF_Click(object sender, EventArgs e)
        {
            foreach (Form formAberto in Application.OpenForms)
            {
                if (formAberto is frmCPF)
                {
                    formAberto.Focus();
                    return;
                }
            }
            frmCPF Cpf = new frmCPF();
            Cpf.Show();
        }

        private void pbxCaraCoroa_Click(object sender, EventArgs e)
        {
            foreach (Form formAberto in Application.OpenForms)
            {
                if (formAberto is frmCaraCoroa)
                {
                    formAberto.Focus();
                    return;
                }
            }
            frmCaraCoroa Moeda = new frmCaraCoroa();
            Moeda.Show();
        }

        private void pbxViagem_Click(object sender, EventArgs e)
        {
            foreach (Form formAberto in Application.OpenForms)
            {
                if (formAberto is frmCalculoViagem)
                {
                    formAberto.Focus();
                    return;
                }
            }
            frmCalculoViagem Viagem = new frmCalculoViagem();
            Viagem.Show();
        }
    }
}

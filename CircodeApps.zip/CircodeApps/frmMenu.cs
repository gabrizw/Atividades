﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CircodeApps
{
    public partial class frmMenu : Form
    {
        public frmMenu()
        {
            InitializeComponent();
            frmSplash splash = new frmSplash();
            splash.Show();
            Application.DoEvents();
            Thread.Sleep(2000);
            splash.Close();
        }

        private void pbxFechar_Click_1(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void pbxCEP_Click_1(object sender, EventArgs e)
        {
            frmBuscarCEP buscarCEP = new frmBuscarCEP();
            buscarCEP.Show();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
